<?php
 require_once PLUGIN_UPLOAD_REALDIR . 'AmazonPaymentsV2/LC_Page_Plugin_AmazonPaymentsV2_Config.php'; $objPage = new LC_Page_Plugin_AmazonPaymentsV2_Config(); register_shutdown_function(array($objPage, 'destroy')); $objPage->init(); $objPage->process(); ?>
