<?php

/*
* AmazonPayments
* Copyright(c) 2023 EC-CUBE CO.,LTD. all rights reserved.
*
* https://www.ec-cube.co.jp/
*
* This program is not free software.
* It applies to terms of service.
*
*/

// テストアカウント情報
define('PLG_AMAZONPAYMENTSV2_TEST_AMAZON_SALLER_ID', 'A2A80MN1XQCQBA');
define('PLG_AMAZONPAYMENTSV2_TEST_PUBLIC_KEY_ID', 'AGWGWRKYSUOV4KUBKCQNV4UB');
define('PLG_AMAZONPAYMENTSV2_TEST_PRIVATE_KEY_PATH', 'downloads/plugin/AmazonPaymentsV2/Test_Eccube_Demo_AmazonPay.pem');

// 本番環境
if ($arrConfig['amazon_prod_mode'] == 1 && $arrConfig['amazon_account_mode'] != 0) {
    define('PLG_AMAZONPAYMENTSV2_ORDER_PREFIX', '');
    define('PLG_AMAZONPAYMENTSV2_SANDBOX', false);
// テスト環境
} else {
    define('PLG_AMAZONPAYMENTSV2_ORDER_PREFIX', date("YmdHis") . '_');
    define('PLG_AMAZONPAYMENTSV2_SANDBOX', true);
}

// SellerCentral受注詳細URL
define('PLG_AMAZONPAYMENTSV2_AMAZON_SC_URL', 'https://sellercentral.amazon.co.jp/hz/me/pmd/payment-details');

// 追加請求金額の最大値
define('PLG_AMAZONPAYMENTSV2_MAX_BILLABLE_AMOUNT', 70000);

// スロットル回復のための実行停止時間(sec)
define('PLG_AMAZONPAYMENTSV2_THLOTTLE_SLEEP', 2);

// 許容可能な最大スロットルエラー回数(1回のリクエスト)
define('PLG_AMAZONPAYMENTSV2_THLOTTLE_ERR_LIMIT', 5);

// Authorize最大実行回数
define('PLG_AMAZONPAYMENTSV2_AUTHORIZE_LIMIT', 3);

// 会員登録情報保持カラム(dtb_order_temp)
define('PLG_AMAZONPAYMENTSV2_CUSTOMER_REGIST', 'memo01');
define('PLG_AMAZONPAYMENTSV2_MAIL_MAGAZINE', 'memo02');
define('PLG_AMAZONPAYMENTSV2_AMAZON_USER_ID', 'memo03');
define('PLG_AMAZONPAYMENTSV2_ORDER_EDIT_FLG', 'memo04');

// AmazonPayments決済情報保持カラム(dtb_order)
define('PLG_AMAZONPAYMENTSV2_AMAZON_PAYMENTS', 'memo01');
define('PLG_AMAZONPAYMENTSV2_AMAZON_STATUS', 'memo03');
define('PLG_AMAZONPAYMENTSV2_BILLABLE_AMOUNT', 'memo04');
define('PLG_AMAZONPAYMENTSV2_AMAZON_TRADING_INFO', 'memo05');
define('PLG_AMAZONPAYMENTSV2_AMAZON_REFERENCE_ID', 'memo06');
define('PLG_AMAZONPAYMENTSV2_AMAZON_STATUS_NAME', 'memo07');

// NOTE:定期プラグインの定数が未定義の場合Warningが出るため定期プラグインが導入されていない場合適当な値を定義する
if (!defined('PLG_IPLPERIODICPURCHASE_FREE_FLG')) {
    define('PLG_IPLPERIODICPURCHASE_FREE_FLG', 'IplPeriodicPurchaseNoExist');
}

// Amazon側受注ステータス
define('PLG_AMAZONPAYMENTSV2_AMAZON_AUTHORI', 1);
define('PLG_AMAZONPAYMENTSV2_AMAZON_CAPTURE', 2);
define('PLG_AMAZONPAYMENTSV2_AMAZON_CANCEL', 3);

// 受注管理からのリクエスト
define('PLG_AMAZONPAYMENTSV2_REQ_CAPTURE', 'amazon_capture_v2');
define('PLG_AMAZONPAYMENTSV2_REQ_CANCEL', 'amazon_cancel_v2');

// リクエストエラー
define('PLG_AMAZONPAYMENTSV2_PAYMENT_METHOD_NOT_ALLOWED', 1);
define('PLG_AMAZONPAYMENTSV2_INVALID_PAYMENT_METHOD', 2);
define('PLG_AMAZONPAYMENTSV2_AMAZON_REJECTED', 3);
define('PLG_AMAZONPAYMENTSV2_TRANSACTION_TIMEDOUT', 4);

// Amazon特典告知バナー
define('USE_AMAZON_BANNER_ON', 1);
define('USE_AMAZON_BANNER_OFF', 0);
define('AMAZON_BANNER_TOP', 1);
define('AMAZON_BANNER_CART', 2);

spl_autoload_register('plgAmazonPaymentsV2Loader');
function plgAmazonPaymentsV2Loader($class) {
    if (strpos($class, 'AmazonPaymentsV2\\') == 0) {
        $class_path = PLUGIN_UPLOAD_REALDIR . str_replace('\\','/',$class) . '.php';
        if (file_exists($class_path)) {
            require_once $class_path;
        }
    }
}