<?php
require_once PLUGIN_UPLOAD_REALDIR . 'AmazonPaymentsV2/class/plg_AmazonPaymentsV2_SC_AmazonPayments.php';
require_once PLUGIN_UPLOAD_REALDIR . 'AmazonPaymentsV2/class/util/plg_AmazonPaymentsV2_SC_Utils.php';
class AmazonPaymentsV2 extends SC_Plugin_Base
{
    public function __construct(array $arrSelfInfo)
    {
        parent::__construct($arrSelfInfo);
        $arrConfig = unserialize($arrSelfInfo['free_field1']);
        require_once PLUGIN_UPLOAD_REALDIR . 'AmazonPaymentsV2/inc/include.php';
        if ($arrConfig['amazon_account_mode'] != 1) {
            $arrConfig['amazon_seller_id'] = PLG_AMAZONPAYMENTSV2_TEST_AMAZON_SALLER_ID;
            $arrConfig['public_key_id'] = PLG_AMAZONPAYMENTSV2_TEST_PUBLIC_KEY_ID;
            $arrConfig['private_key_path'] = PLG_AMAZONPAYMENTSV2_TEST_PRIVATE_KEY_PATH;
            $arrConfig['amazon_client_id'] = $arrConfig['test_amazon_client_id'];
        }
        if (!isset($arrConfig['use_amazon_banner'])) {
            $arrConfig['use_amazon_banner'] = [AMAZON_BANNER_TOP, AMAZON_BANNER_CART];
        }
        $arrUseAmazonBanner = array(AMAZON_BANNER_TOP => 'トップページ', AMAZON_BANNER_CART => 'カート画面');
        foreach ($arrUseAmazonBanner as $key => $value) {
            if (!isset($arrConfig['amazon_banner_size_' . $key])) {
                $objQuery = &SC_Query_Ex::getSingletonInstance();
                $arrConfig['amazon_banner_size_' . $key] = plg_AmazonPaymentsV2_SC_Utils::sfSelectAmazonBannerDefaultCode($objQuery, $key);
            }
            if (!isset($arrConfig['amazon_banner_place_' . $key])) {
                $arrConfig['amazon_banner_place_' . $key] = 'auto';
            }
        }
        foreach ($arrConfig as $key => $value) {
            if (is_array($value)) {
                foreach ($value as $key2) {
                    define('PLG_AMAZONPAYMENTSV2_' . mb_strtoupper($key . '_' . $key2), 'selected');
                }
            } else {
                define('PLG_AMAZONPAYMENTSV2_' . mb_strtoupper($key), $value);
            }
        }
    }
    static function install($arrPlugin, $objPluginInstaller = null)
    {
        plg_AmazonPaymentsV2_SC_Utils::printLog("AmazonPayments install start.");
        $copy_dir = PLUGIN_UPLOAD_REALDIR . $arrPlugin['plugin_code'] . '/copy/';
        if (copy($copy_dir . 'logo.png', PLUGIN_HTML_REALDIR . $arrPlugin['plugin_code'] . '/logo.png') === false);
        SC_Utils_Ex::copyDirectory($copy_dir . 'html/', HTML_REALDIR);
        SC_Utils_Ex::copyDirectory($copy_dir . 'Smarty/pc/', TEMPLATE_REALDIR);
        SC_Utils_Ex::copyDirectory($copy_dir . 'Smarty/sphone/', SMARTPHONE_TEMPLATE_REALDIR);
        self::installSQL();
        plg_AmazonPaymentsV2_SC_Utils::autoSendMail(__FUNCTION__);
        plg_AmazonPaymentsV2_SC_Utils::printLog("AmazonPayments install end.");
    }
    static function uninstall($arrPlugin, $objPluginInstaller = null)
    {
        plg_AmazonPaymentsV2_SC_Utils::deleteHtmlFile();
        plg_AmazonPaymentsV2_SC_Utils::deleteUserDataFile();
        plg_AmazonPaymentsV2_SC_Utils::deleteTemplateFile();
        self::uninstallSQL();
        SC_Helper_FileManager_Ex::deleteFile(PLUGIN_HTML_REALDIR . $arrPlugin['plugin_code']);
        plg_AmazonPaymentsV2_SC_Utils::autoSendMail(__FUNCTION__);
    }
    static function enable($arrPlugin, $objPluginInstaller = null)
    {
    }
    static function disable($arrPlugin, $objPluginInstaller = null)
    {
    }
    function register(SC_Helper_Plugin $objHelperPlugin, $priority)
    {
        $objHelperPlugin->addAction('prefilterTransform', array(&$this, 'prefilterTransform'));
        $objHelperPlugin->addAction('LC_Page_Cart_action_before', array(&$this, 'redirectUrl'));
        $objHelperPlugin->addAction('LC_Page_Cart_action_after', array(&$this, 'cartActionAfter'));
        $objHelperPlugin->addAction('LC_Page_Mypage_Login_action_before', array(&$this, 'redirectUrl'));
        $objHelperPlugin->addAction('LC_Page_Mypage_Login_action_after', array(&$this, 'mypageLoginActionAfter'));
        $objHelperPlugin->addAction('LC_Page_Shopping_action_before', array(&$this, 'redirectUrl'));
        $objHelperPlugin->addAction('LC_Page_Shopping_action_after', array(&$this, 'shoppingActionAfter'));
        $objHelperPlugin->addAction('LC_Page_Shopping_Payment_action_after', array(&$this, 'shoppingPaymentActionAfter'));
        $objHelperPlugin->addAction('LC_Page_Forgot_action_after', array(&$this, 'forgotActionAfter'));
        $objHelperPlugin->addAction('LC_Page_Admin_Order_action_before', array(&$this, 'adminOrderActionBefore'));
        $objHelperPlugin->addAction('LC_Page_Admin_Order_action_after', array(&$this, 'adminOrderActionAfter'));
        $objHelperPlugin->addAction('LC_Page_Index_action_after', array(&$this, 'indexActionAfter'));
    }
    function indexActionAfter(LC_Page_Ex $objPage)
    {
        if (PLG_AMAZONPAYMENTSV2_AMAZON_BANNER_PLACE_1 == 'manual') {
            $objQuery = SC_Query_Ex::getSingletonInstance();
            $objPage->strAmazonBannerCodeTop = plg_AmazonPaymentsV2_SC_Utils::sfSelectAmazonBannerCode($objQuery, AMAZON_BANNER_TOP, PLG_AMAZONPAYMENTSV2_AMAZON_BANNER_SIZE_1, PLG_AMAZONPAYMENTSV2_AMAZON_SELLER_ID);
        }
    }
    function cartActionAfter(LC_Page_Ex $objPage)
    {
        if (empty($objPage->cartItems)) {
            return;
        }
        $objAmznPay = new plg_AmazonPaymentsV2_SC_AmazonPayments();
        $arrPayload = array();
        $arrSignature = array();
        foreach ($objPage->cartItems as $key => $cartItem) {
            $payload = $objAmznPay->createCheckoutSessionPayload($key);
            $arrPayload[$key] = $payload;
            $arrSignature[$key] = $objAmznPay->signaturePayload($payload);
        }
        $arrAmazonDelivList = $this->cartCheckAble($objPage);
        $arrAmazonProductTypeId = array();
        foreach ($arrAmazonDelivList as $AmazonDelivList) {
            $arrAmazonProductTypeId[] = (int)$AmazonDelivList['product_type_id'];
        }
        $objPage->arrPayload = $arrPayload;
        $objPage->arrSignature = $arrSignature;
        $objPage->arrAmazonDelivList = $arrAmazonProductTypeId;
        if (PLG_AMAZONPAYMENTSV2_AMAZON_BANNER_PLACE_2 == 'manual') {
            $objQuery = SC_Query_Ex::getSingletonInstance();
            $objPage->strAmazonBannerCodeCart = plg_AmazonPaymentsV2_SC_Utils::sfSelectAmazonBannerCode($objQuery, AMAZON_BANNER_CART, PLG_AMAZONPAYMENTSV2_AMAZON_BANNER_SIZE_2, PLG_AMAZONPAYMENTSV2_AMAZON_SELLER_ID);
        }
    }
    function mypageLoginActionAfter(LC_Page_Ex $objPage)
    {
        if ((($objPage->arrPageLayout['device_type_id'] == DEVICE_TYPE_PC) && (PLG_AMAZONPAYMENTSV2_PC_AMAZON_LOGIN_BUTTON_SELECT_MYPAGE == 'selected')) || (($objPage->arrPageLayout['device_type_id'] == DEVICE_TYPE_SMARTPHONE) && (PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_LOGIN_BUTTON_SELECT_MYPAGE == 'selected'))) {
            $return_url = HTTPS_URL . "mypage/plg_AmazonPaymentsV2_login.html";
            $this->setAmazonLoginParameter($objPage, $return_url);
        }
    }
    function shoppingActionAfter(LC_Page_Ex $objPage)
    {
        if ((($objPage->arrPageLayout['device_type_id'] == DEVICE_TYPE_PC) && (PLG_AMAZONPAYMENTSV2_PC_AMAZON_LOGIN_BUTTON_SELECT_SHOPPING == 'selected')) || (($objPage->arrPageLayout['device_type_id'] == DEVICE_TYPE_SMARTPHONE) && (PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_LOGIN_BUTTON_SELECT_SHOPPING == 'selected'))) {
            $return_url = HTTPS_URL . "shopping/plg_AmazonPaymentsV2_login.html";
            $this->setAmazonLoginParameter($objPage, $return_url);
        }
    }
    function setAmazonLoginParameter(&$objPage, $return_url)
    {
        $objAmznPay = new plg_AmazonPaymentsV2_SC_AmazonPayments();
        $objPage->amazon_login_payload = $objAmznPay->generateSigninPayload($return_url);
        $objPage->amazon_login_signature = $objAmznPay->signaturePayload($objPage->amazon_login_payload);
    }
    function prefilterTransform(&$source, LC_Page_Ex $objPage, $filename)
    {
        $objTransform = new SC_Helper_Transform_Ex($source);
        $template_dir = PLUGIN_UPLOAD_REALDIR . 'AmazonPaymentsV2/templates/';
        $objQuery = SC_QUERY_EX::getSingletonInstance();
        switch ($objPage->arrPageLayout['device_type_id']) {
            case DEVICE_TYPE_PC:
                if (strpos($filename, 'cart/index.tpl') !== false) {
                    $objTransform->select('form')->insertBefore(file_get_contents($template_dir . 'pc/cart/plg_AmazonPaymentsV2_index_js.tpl'));
                    if (PLG_AMAZONPAYMENTSV2_PC_AMAZON_BUTTON_PLACE_CART == 'auto') {
                        $objTransform->select('div.btn_area')->find('ul')->appendChild(file_get_contents($template_dir . 'pc/cart/plg_AmazonPaymentsV2_index_button.tpl'));
                    } else {
                        $objTransform->select('div#amazon_custom_button', null, false)->replaceElement(file_get_contents($template_dir . 'pc/cart/plg_AmazonPaymentsV2_index_custom_button.tpl'));
                    }
                    if (PLG_AMAZONPAYMENTSV2_USE_AMAZON_BANNER_2 == 'selected') {
                        if (PLG_AMAZONPAYMENTSV2_AMAZON_BANNER_PLACE_2 == 'manual') {
                            $objTransform->select('div.form_area')->appendChild(file_get_contents($template_dir . 'pc/amazonbanner_cart.tpl'));
                        } else {
                            $code = plg_AmazonPaymentsV2_SC_Utils::sfSelectAmazonBannerCode($objQuery, AMAZON_BANNER_CART, PLG_AMAZONPAYMENTSV2_AMAZON_BANNER_SIZE_2, PLG_AMAZONPAYMENTSV2_AMAZON_SELLER_ID);
                            $objTransform->select('div.form_area')->appendChild($code);
                        }
                    }
                }
                if (strpos($filename, 'mypage/login.tpl') !== false && PLG_AMAZONPAYMENTSV2_PC_AMAZON_LOGIN_BUTTON_SELECT_MYPAGE == 'selected') {
                    $objTransform->select('#undercolumn')->insertBefore(file_get_contents($template_dir . 'pc/mypage/plg_AmazonPaymentsV2_login_js.tpl'));
                    if (PLG_AMAZONPAYMENTSV2_PC_AMAZON_LOGIN_BUTTON_PLACE_MYPAGE == 'auto') {
                        $objTransform->select('div.login_area')->appendChild(file_get_contents($template_dir . 'pc/mypage/plg_AmazonPaymentsV2_login_button.tpl'));
                    }
                }
                if (strpos($filename, 'shopping/index.tpl') !== false && PLG_AMAZONPAYMENTSV2_PC_AMAZON_LOGIN_BUTTON_SELECT_SHOPPING == 'selected') {
                    $objTransform->select('#undercolumn')->insertBefore(file_get_contents($template_dir . 'pc/shopping/plg_AmazonPaymentsV2_login_js.tpl'));
                    if (PLG_AMAZONPAYMENTSV2_PC_AMAZON_LOGIN_BUTTON_PLACE_SHOPPING == 'auto') {
                        $objTransform->select('form#member_form')->appendChild(file_get_contents($template_dir . 'pc/shopping/plg_AmazonPaymentsV2_login_button.tpl'));
                    }
                }
                if (strpos($filename, 'guide.tpl') !== false && PLG_AMAZONPAYMENTSV2_USE_AMAZON_BANNER_1 == 'selected') {
                    if (PLG_AMAZONPAYMENTSV2_AMAZON_BANNER_PLACE_1 == 'manual') {
                        $objTransform->select('div.block_outer')->appendChild(file_get_contents($template_dir . 'pc/amazonbanner_top.tpl'));
                    } else {
                        $code = plg_AmazonPaymentsV2_SC_Utils::sfSelectAmazonBannerCode($objQuery, AMAZON_BANNER_TOP, PLG_AMAZONPAYMENTSV2_AMAZON_BANNER_SIZE_1, PLG_AMAZONPAYMENTSV2_AMAZON_SELLER_ID);
                        $objTransform->select('div.block_outer')->appendChild($code);
                    }
                }
                break;
            case DEVICE_TYPE_SMARTPHONE:
                if (strpos($filename, 'cart/index.tpl') !== false) {
                    $objTransform->select('#undercolumn')->insertBefore(file_get_contents($template_dir . 'sphone/cart/plg_AmazonPaymentsV2_index_js.tpl'));
                    if (PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_BUTTON_PLACE_CART == 'auto') {
                        $objTransform->select('div.btn_area_btm')->appendChild(file_get_contents($template_dir . 'sphone/cart/plg_AmazonPaymentsV2_index_button.tpl'));
                    } else {
                        $objTransform->select('div#amazon_custom_button_1', null, false)->replaceElement(file_get_contents($template_dir . 'sphone/cart/plg_AmazonPaymentsV2_index_custom_button_1.tpl'));
                        $objTransform->select('div#amazon_custom_button_2', null, false)->replaceElement(file_get_contents($template_dir . 'sphone/cart/plg_AmazonPaymentsV2_index_custom_button_2.tpl'));
                    }
                }
                if (strpos($filename, 'mypage/login.tpl') !== false && PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_LOGIN_BUTTON_SELECT_MYPAGE == 'selected') {
                    $objTransform->select('#slidewindow')->insertBefore(file_get_contents($template_dir . 'sphone/mypage/plg_AmazonPaymentsV2_login_js.tpl'));
                    if (PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_LOGIN_BUTTON_PLACE_MYPAGE == 'auto') {
                        $objTransform->select('div.login_area')->appendChild(file_get_contents($template_dir . 'sphone/mypage/plg_AmazonPaymentsV2_login_button.tpl'));
                    }
                }
                if (strpos($filename, 'shopping/index.tpl') !== false && PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_LOGIN_BUTTON_SELECT_SHOPPING == 'selected') {
                    $objTransform->select('#slidewindow')->insertBefore(file_get_contents($template_dir . 'sphone/shopping/plg_AmazonPaymentsV2_login_js.tpl'));
                    if (PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_LOGIN_BUTTON_PLACE_SHOPPING == 'auto') {
                        $objTransform->select('div.login_area')->appendChild(file_get_contents($template_dir . 'sphone/shopping/plg_AmazonPaymentsV2_login_button.tpl'));
                    }
                }
                break;
            case DEVICE_TYPE_ADMIN:
            default:
                if (strpos($filename, 'order/index.tpl') !== false) {
                    $objTransform->select('div#order')->insertBefore(file_get_contents($template_dir . 'admin/order/plg_AmazonPaymentsV2_index_add_1.tpl'));
                    $objTransform->select('form#form1')->appendFirst(file_get_contents($template_dir . 'admin/order/plg_AmazonPaymentsV2_index_add_2.tpl'));
                    $objTransform->select('table.list')->insertBefore(file_get_contents($template_dir . 'admin/order/plg_AmazonPaymentsV2_index_add_3.tpl'));
                    $objTransform->select('table.list')->appendFirst(file_get_contents($template_dir . 'admin/order/plg_AmazonPaymentsV2_index_add_4.tpl'));
                    $objTransform->select('table.list')->find('tr', 0)->find('th', 6)->insertAfter(file_get_contents($template_dir . 'admin/order/plg_AmazonPaymentsV2_index_add_5.tpl'));
                    $objTransform->select('table.list')->find('tr', 1)->find('td', 6)->insertAfter(file_get_contents($template_dir . 'admin/order/plg_AmazonPaymentsV2_index_add_6.tpl'));
                }
        }
        $source = $objTransform->getHTML();
    }
    function redirectUrl(LC_Page_Ex $objPage)
    {
        if (empty($_SERVER['HTTPS'])) {
            $url = $objPage->arrPageLayout['url'];
            $redirect_flg = false;
            switch ($objPage->arrPageLayout['device_type_id']) {
                case DEVICE_TYPE_PC:
                    if (strpos($url, 'cart/index.php') !== false) {
                        $redirect_flg = true;
                    }
                    if (strpos($url, 'mypage/login.php') !== false && PLG_AMAZONPAYMENTSV2_PC_AMAZON_LOGIN_BUTTON_SELECT_MYPAGE == 'selected') {
                        $redirect_flg = true;
                    }
                    if (strpos($url, 'shopping/index.php') !== false && PLG_AMAZONPAYMENTSV2_PC_AMAZON_LOGIN_BUTTON_SELECT_SHOPPING == 'selected') {
                        $redirect_flg = true;
                    }
                    break;
                case DEVICE_TYPE_SMARTPHONE:
                    if (strpos($url, 'cart/index.php') !== false) {
                        $redirect_flg = true;
                    }
                    if (strpos($url, 'mypage/login.php') !== false && PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_LOGIN_BUTTON_SELECT_MYPAGE == 'selected') {
                        $redirect_flg = true;
                    }
                    if (strpos($url, 'shopping/index.php') !== false && PLG_AMAZONPAYMENTSV2_SPHONE_AMAZON_LOGIN_BUTTON_SELECT_SHOPPING == 'selected') {
                        $redirect_flg = true;
                    }
                    break;
                default:
                    break;
            }
            if ($redirect_flg) {
                header("Location: https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}");
                exit;
            }
        }
    }
    function shoppingPaymentActionAfter(LC_Page_Ex $objPage)
    {
        $amazon_payment_id = plg_AmazonPaymentsV2_SC_Utils::getAmazonPaymentId();
        foreach ($objPage->arrPayment as $key => $payment) {
            if ($payment['payment_id'] == $amazon_payment_id) {
                unset($objPage->arrPayment[$key]);
                $objPage->arrPayment = array_values($objPage->arrPayment);
            }
        }
    }
    function forgotActionAfter(LC_Page_Ex $objPage)
    {
        if ($_POST['mode'] == 'mail_check') {
            $objQuery = &SC_Query_Ex::getSingletonInstance();
            $where = '(email = ? OR email_mobile = ?) AND del_flg = 0';
            $arrVal = array($objPage->arrForm['email'], $objPage->arrForm['email']);
            $result = $objQuery->select('reminder, plg_amazonpaymentsv2_buyer_id', 'dtb_customer', $where, $arrVal);
            if (!isset($result[0]['reminder']) && !isset($objPage->arrReminder[$result[0]['reminder']]) && isset($result[0]['plg_amazonpaymentsv2_buyer_id'])) {
                $contact_url = HTTPS_URL . "contact/" . DIR_INDEX_PATH;
                $objPage->errmsg = <<<__EOS__
<div class="attention alignL">
ご登録されたメールアドレスはAmazon Payからのご登録だったため、申し訳ございませんが、この機能はご利用できません。<br/>
<br/>
Amazon Payをご利用のお客様には、初回ご注文時にお送りしたメールに仮パスワードを記載させて頂いております。ご確認をお願いいたします。<br/>
<br/>
上記メールがご不明の場合、お手数ですが、<a href="{$contact_url}">お問い合わせページ</a>からお問い合わせください。
</div>
__EOS__;
            }
        }
    }
    function adminOrderActionBefore(LC_Page_Ex $objPage)
    {
        $amazon_request = $_POST['amazon_request'];
        if ($amazon_request == PLG_AMAZONPAYMENTSV2_REQ_CAPTURE || $amazon_request == PLG_AMAZONPAYMENTSV2_REQ_CANCEL) {
            if (!empty($_POST['amazon_order_id'])) {
                $arrOrderId = array($_POST['amazon_order_id']);
            } else {
                $arrOrderId = $_POST[$amazon_request];
            }
            $arrParameter = $this->getParameter($arrOrderId);
            if (empty($arrParameter)) {
                plg_AmazonPaymentsV2_SC_Utils::printLog("ERROR: request_parameter empty. POST=" . print_r($_POST, true));
            }
            $arrErr = '';
            foreach ($arrParameter as $parameter) {
                $arrErr .= $this->amazonRequest($amazon_request, $parameter);
            }
            $objPage->amazonErr = $arrErr;
        }
    }
    function adminOrderActionAfter(LC_Page_Ex $objPage)
    {
        $arrAmazonResults = array();
        $searchOrder = array();
        $searchOrder = $objPage->arrResults;
        foreach ((array)$searchOrder as $order) {
            if ((strpos($order[PLG_AMAZONPAYMENTSV2_AMAZON_PAYMENTS], 'amazonpaymentsV2') !== false) || (strpos($order[PLG_AMAZONPAYMENTSV2_AMAZON_PAYMENTS], 'amazonpayments') !== false)) {
                $arrAmazonTradingInfo = unserialize($order[PLG_AMAZONPAYMENTSV2_AMAZON_TRADING_INFO]);
                $billableAmount = $order[PLG_AMAZONPAYMENTSV2_BILLABLE_AMOUNT];
                $payment_total = $order['payment_total'];
                $sumAuthoriAmount = 0;
                $sumCaptureAmount = 0;
                foreach ($arrAmazonTradingInfo as $amazonTradingInfo) {
                    $sumAuthoriAmount += $amazonTradingInfo['authori_amount'];
                    $sumCaptureAmount += $amazonTradingInfo['capture_amount'];
                }
                if ($payment_total <= $sumCaptureAmount || $order[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS] == PLG_AMAZONPAYMENTSV2_AMAZON_CANCEL || $order[PLG_IPLPERIODICPURCHASE_FREE_FLG] == 'free') {
                    $amazonCaptureDisp = 0;
                } elseif ($payment_total - $sumCaptureAmount > $billableAmount) {
                    $amazonCaptureDisp = 1;
                } else {
                    if ($payment_total < $sumAuthoriAmount && $order[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS] == PLG_AMAZONPAYMENTSV2_AMAZON_AUTHORI) {
                        $amazonDiffAmount = $sumAuthoriAmount - $payment_total;
                        $amazonCaptureDisp = 2;
                    } elseif ($payment_total > $sumAuthoriAmount && $order[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS] == PLG_AMAZONPAYMENTSV2_AMAZON_AUTHORI) {
                        $amazonDiffAmount = $payment_total - $sumAuthoriAmount;
                        $amazonCaptureDisp = 3;
                    } elseif ($payment_total > $sumCaptureAmount && $order[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS] == PLG_AMAZONPAYMENTSV2_AMAZON_CAPTURE) {
                        $amazonDiffAmount = $payment_total - $sumCaptureAmount;
                        $amazonCaptureDisp = 3;
                    } else {
                        $amazonCaptureDisp = 4;
                    }
                }
                if ($amazonCaptureDisp == 3 && !empty($order['plg_ipl_periodic_purchase_periodic_purchase_id'])) {
                    $amazonCaptureDisp = 1;
                }
                if ($order[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS] == PLG_AMAZONPAYMENTSV2_AMAZON_CANCEL || $order[PLG_IPLPERIODICPURCHASE_FREE_FLG] == 'free') {
                    $amazonCancelDisp = 0;
                } elseif ($order[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS] == PLG_AMAZONPAYMENTSV2_AMAZON_CAPTURE) {
                    if ($payment_total > $sumCaptureAmount) {
                        $amazonCancelDisp = 1;
                    } elseif ($payment_total < $sumCaptureAmount) {
                        $amazonDiffAmount = $sumCaptureAmount - $payment_total;
                        $amazonCancelDisp = 2;
                    } else {
                        $amazonCancelDisp = 3;
                    }
                } else {
                    $amazonCancelDisp = 3;
                }
                $order['amazon_diff_amount'] = $amazonDiffAmount;
                $order['amazon_capture_disp'] = $amazonCaptureDisp;
                $order['amazon_cancel_disp'] = $amazonCancelDisp;
            }
            $arrAmazonResults[] = $order;
        }
        $objPage->arrResults = $arrAmazonResults;
        $objPage->arrAmazonStatus = array(PLG_AMAZONPAYMENTSV2_AMAZON_AUTHORI => 'オーソリ', PLG_AMAZONPAYMENTSV2_AMAZON_CAPTURE => '売上', PLG_AMAZONPAYMENTSV2_AMAZON_CANCEL => '取消',);
        $objPage->existsAmazonPaymentsV1 = plg_AmazonPaymentsV2_SC_Utils::existsAmazonPaymentsV1();
    }
    function amazonRequest($amazon_request, $parameter)
    {
        $objAmznPay = new plg_AmazonPaymentsV2_SC_AmazonPayments();
        $objPurchase = new SC_Helper_Purchase_Ex();
        $objQuery = &SC_Query_Ex::getSingletonInstance();
        $process = $amazon_request == PLG_AMAZONPAYMENTSV2_REQ_CAPTURE ? '売上' : '取消';
        $amazonErr = '';
        $order_id = $parameter['order_id'];
        $amazonChargePermissionId = $parameter[PLG_AMAZONPAYMENTSV2_AMAZON_REFERENCE_ID];
        $arrAmazonTradingInfo = unserialize($parameter[PLG_AMAZONPAYMENTSV2_AMAZON_TRADING_INFO]);
        $amazonStatus = $parameter[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS];
        $sumAuthoriAmount = 0;
        $sumCaptureAmount = 0;
        foreach ($arrAmazonTradingInfo as $amazonTradingInfo) {
            $sumAuthoriAmount += $amazonTradingInfo['authori_amount'];
            $sumCaptureAmount += $amazonTradingInfo['capture_amount'];
        }
        $payment_total = $parameter['payment_total'];
        $billableAmount = $parameter[PLG_AMAZONPAYMENTSV2_BILLABLE_AMOUNT];
        $is_periodic_purchase = !empty($parameter['plg_ipl_periodic_purchase_periodic_purchase_id']);
        $totalBillingAmount = $payment_total - $sumCaptureAmount;
        if ($amazon_request == PLG_AMAZONPAYMENTSV2_REQ_CANCEL && $payment_total == $sumCaptureAmount) {
            $allRefund_flg = true;
        } else {
            $allRefund_flg = false;
        }
        $totalRefundAmount = $allRefund_flg ? $payment_total : $sumCaptureAmount - $payment_total;
        $resultAmazonTradingInfo = array();
        foreach ($arrAmazonTradingInfo as $key => $amazonTradingInfo) {
            $amazonChargeId = $amazonTradingInfo['charge_id'];
            if (!$amazonChargeId) {
                $amazonChargeId = substr_replace($amazonTradingInfo['id'], "C", 20, 1);
            }
            $authoriAmount = $amazonTradingInfo['authori_amount'];
            $captureAmount = $amazonTradingInfo['capture_amount'];
            $refundCount = $amazonTradingInfo['refund_count'];
            if ($amazon_request == PLG_AMAZONPAYMENTSV2_REQ_CAPTURE) {
                if ($captureAmount > 0 || $totalBillingAmount == 0) {
                    $resultAmazonTradingInfo[$key] = $amazonTradingInfo;
                } else {
                    $billingAmount = $authoriAmount > $totalBillingAmount ? $totalBillingAmount : $authoriAmount;
                    $r = $objAmznPay->captureCharge($amazonChargeId, $billingAmount);
                    if (isset($r->reasonCode)) {
                        plg_AmazonPaymentsV2_SC_Utils::printLog("ERROR: aws captureCharge request error from admin_order r=" . var_export($r, true));
                        break;
                    }
                    $amazonTradingInfo = array('charge_id' => $amazonChargeId, 'authori_amount' => $authoriAmount, 'capture_amount' => $billingAmount, 'refund_count' => $refundCount,);
                    $resultAmazonTradingInfo[$key] = $amazonTradingInfo;
                    $totalBillingAmount = $totalBillingAmount - $billingAmount;
                    $billableAmount = $billableAmount - $billingAmount;
                }
                if (($payment_total > $sumAuthoriAmount && $amazonStatus == PLG_AMAZONPAYMENTSV2_AMAZON_AUTHORI) || ($totalBillingAmount > 0 && $amazonStatus == PLG_AMAZONPAYMENTSV2_AMAZON_CAPTURE)) {
                    if ($amazonStatus == PLG_AMAZONPAYMENTSV2_AMAZON_AUTHORI) {
                        $addAmount = $payment_total - $sumAuthoriAmount;
                    } else {
                        $addAmount = $totalBillingAmount;
                    }
                    $r = $objAmznPay->createCharge($amazonChargePermissionId, $addAmount);
                    if (isset($r->reasonCode) || !isset($r->chargeId)) {
                        plg_AmazonPaymentsV2_SC_Utils::printLog("ERROR: aws request createCharge error from admin_order r=" . var_export($r, true));
                        break;
                    }
                    $newAmazonChargeId = $r->chargeId;
                    $r = $objAmznPay->captureCharge($newAmazonChargeId, $addAmount);
                    if (isset($r->reasonCode)) {
                        plg_AmazonPaymentsV2_SC_Utils::printLog('aws request error from admin_order r=' . var_export($r, true));
                        break;
                    }
                    $addAmazonTradingInfo = array('charge_id' => $newAmazonChargeId, 'authori_amount' => $addAmount, 'capture_amount' => $addAmount, 'refund_count' => 0,);
                    $resultAmazonTradingInfo[count($arrAmazonTradingInfo)] = $addAmazonTradingInfo;
                    $totalBillingAmount = $totalBillingAmount - $addAmount;
                    $billableAmount = $billableAmount - $addAmount;
                }
            } else {
                $arrOrderOld = $objQuery->getRow('status, add_point, use_point, customer_id', 'dtb_order', 'order_id = ?', array($order_id));
                $newStatus = ORDER_CANCEL;
                $newUsePoint = $arrOrderOld['use_point'];
                $newAddPoint = $arrOrderOld['add_point'];
                if (USE_POINT !== false && $arrOrderOld['customer_id']) {
                    $addCustomerPoint = 0;
                    if ($objPurchase->isUsePoint($arrOrderOld['status'])) {
                        $addCustomerPoint += $arrOrderOld['use_point'];
                    }
                    if ($objPurchase->isUsePoint($newStatus)) {
                        $addCustomerPoint -= $newUsePoint;
                    }
                    if ($objPurchase->isAddPoint($arrOrderOld['status'])) {
                        $addCustomerPoint -= $arrOrderOld['add_point'];
                    }
                    if ($objPurchase->isAddPoint($newStatus)) {
                        $addCustomerPoint += $newAddPoint;
                    }
                    if ($addCustomerPoint < 0) {
                        $point = $objQuery->get('point', 'dtb_customer', 'customer_id = ?', array($arrOrderOld['customer_id']));
                        $total_point = $point + $addCustomerPoint;
                        if ($total_point < 0) {
                            $amazonErr = '■注文番号:' . $order_id . 'の決済で下記のエラーが発生しました。<br>' . '該当会員の所持ポイントがマイナスになるため処理を終了しました。<br>';
                            return $amazonErr;
                        }
                    }
                }
                if ($sumCaptureAmount == 0) {
                    if ($is_periodic_purchase !== false) {
                    } else {
                        $arrMemo03 = $objQuery->getRow('memo03', 'dtb_order', 'order_id = ?', array($order_id));
                        $cancelPendingCharges = $arrMemo03['memo03'] == PLG_AMAZONPAYMENTSV2_AMAZON_AUTHORI;
                        $r = $objAmznPay->closeChargePermission($amazonChargePermissionId, null, $cancelPendingCharges);
                    }
                    $resultAmazonTradingInfo[$key] = $amazonTradingInfo;
                    $cancel_flg = true;
                } elseif ($totalRefundAmount == 0 || $captureAmount == 0) {
                    $resultAmazonTradingInfo[$key] = $amazonTradingInfo;
                } else {
                    $refundAmount = $captureAmount > $totalRefundAmount ? $totalRefundAmount : $captureAmount;
                    $refundCount = $refundCount + 1;
                    $r = $objAmznPay->createRefund($amazonChargeId, $refundAmount);
                    if (isset($r->reasonCode)) {
                        plg_AmazonPaymentsV2_SC_Utils::printLog("ERROR: aws createRefund request error from admin_order r=" . var_export($r, true));
                        break;
                    }
                    $amazonTradingInfo = array('charge_id' => $amazonChargeId, 'authori_amount' => $authoriAmount, 'capture_amount' => $captureAmount - $refundAmount, 'refund_count' => $refundCount,);
                    $resultAmazonTradingInfo[$key] = $amazonTradingInfo;
                    $totalRefundAmount = $totalRefundAmount - $refundAmount;
                }
            }
        }
        if (isset($r->reasonCode)) {
            $amazonErr = '■注文番号:' . $order_id . 'の決済で下記のエラーが発生しました。<br>' . 'リクエストを受け付けないため処理を終了しました。<br>';
        } elseif (is_object($r)) {
            $sqlVal = array();
            $status = null;
            if ($cancel_flg || $allRefund_flg) {
                $sqlVal[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS] = PLG_AMAZONPAYMENTSV2_AMAZON_CANCEL;
                $sqlVal[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS_NAME] = '取消';
                $status = ORDER_CANCEL;
            } else {
                $sqlVal[PLG_AMAZONPAYMENTSV2_BILLABLE_AMOUNT] = $billableAmount;
                $sqlVal[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS] = PLG_AMAZONPAYMENTSV2_AMAZON_CAPTURE;
                $sqlVal[PLG_AMAZONPAYMENTSV2_AMAZON_STATUS_NAME] = '売上';
                $sqlVal['payment_date'] = 'CURRENT_TIMESTAMP';
            }
            $sqlVal[PLG_AMAZONPAYMENTSV2_AMAZON_TRADING_INFO] = serialize($resultAmazonTradingInfo);
            $sqlVal['update_date'] = 'CURRENT_TIMESTAMP';
            $objQuery->begin();
            $objPurchase->sfUpdateOrderStatus($order_id, $status, null, null, $sqlVal);
            $objQuery->commit();
        } else {
            $amazonErr = '■注文番号:' . $order_id . 'の決済で下記のエラーが発生しました。<br>' . $process . 'リクエストに失敗しました。<br>' . var_export($r, true) . '<br>';
        }
        return $amazonErr;
    }
    function getParameter($arrOrderId)
    {
        $objQuery = &SC_Query_Ex::getSingletonInstance();
        $cols = '*';
        $where = 'order_id IN (' . SC_Utils_Ex::repeatStrWithSeparator('?', count($arrOrderId)) . ')';
        $result = $objQuery->select($cols, 'dtb_order', $where, $arrOrderId);
        return $result;
    }
    function installSQL()
    {
        $objQuery = &SC_Query_Ex::getSingletonInstance();
        $objDB = new SC_Helper_DB_Ex();
        plg_AmazonPaymentsV2_SC_Utils::printLog("installSQL start.");
        $objDB->sfColumnExists('dtb_customer', 'plg_amazonpaymentsv2_buyer_id', 'text', "", true);
        self::lfInsertPagelayout($objQuery);
        self::lfInsertCsv($objQuery);
        self::lfInsertConstants($objQuery);
        self::lfInsertPayment($objQuery);
        plg_AmazonPaymentsV2_SC_Utils::sfCreateAmazonBannerTable($objQuery);
        plg_AmazonPaymentsV2_SC_Utils::sfInsertAmazonBannerRecords($objQuery);
        plg_AmazonPaymentsV2_SC_Utils::printLog("installSQL end.");
    }
    function uninstallSQL()
    {
        $objQuery = &SC_Query_Ex::getSingletonInstance();
        $objQuery->query("ALTER TABLE dtb_customer DROP plg_amazonpaymentsv2_buyer_id;");
        self::lfDeletePayment($objQuery);
        self::lfDeletePagelayout($objQuery);
        self::lfDeleteCsv($objQuery);
        self::lfDeleteConstants($objQuery);
        plg_AmazonPaymentsV2_SC_Utils::sfDropAmazonBannerTable($objQuery);
    }
    function lfInsertPagelayout(&$objQuery)
    {
        $arrPageData = self::lfGetPagelayout();
        foreach ($arrPageData as $pageData) {
            if (!$objQuery->exists('dtb_pagelayout', 'device_type_id = ? AND url = ?', array(DEVICE_TYPE_PC, $pageData['file_name'] . '.php'))) {
                $arrVal = array('device_type_id' => DEVICE_TYPE_PC, 'page_name' => $pageData['page_name'], 'url' => $pageData['file_name'] . '.php', 'filename' => $pageData['file_name'], 'header_chk' => 1, 'footer_chk' => 1, 'edit_flg' => 2, 'create_date' => 'CURRENT_TIMESTAMP', 'update_date' => 'CURRENT_TIMESTAMP',);
                $page_id = $objQuery->get('max(page_id) + 1', 'dtb_pagelayout', 'device_type_id = ?', array(DEVICE_TYPE_PC));
                $arrVal['page_id'] = $page_id;
                $objQuery->insert('dtb_pagelayout', $arrVal);
            } else {
                plg_AmazonPaymentsV2_SC_Utils::printLog("installSQL already exist record device_type_id=" . DEVICE_TYPE_PC . " url=" . $pageData['file_name'] . ".php' in dtb_pagelayout.");
            }
            if (!$objQuery->exists('dtb_pagelayout', 'device_type_id = ? AND url = ?', array(DEVICE_TYPE_SMARTPHONE, $pageData['file_name'] . '.php'))) {
                $arrVal = array('device_type_id' => DEVICE_TYPE_SMARTPHONE, 'page_name' => $pageData['page_name'], 'url' => $pageData['file_name'] . '.php', 'filename' => $pageData['file_name'], 'header_chk' => 1, 'footer_chk' => 1, 'edit_flg' => 2, 'create_date' => 'CURRENT_TIMESTAMP', 'update_date' => 'CURRENT_TIMESTAMP',);
                $page_id = $objQuery->get('max(page_id) + 1', 'dtb_pagelayout', 'device_type_id = ?', array(DEVICE_TYPE_SMARTPHONE));
                $arrVal['page_id'] = $page_id;
                $objQuery->insert('dtb_pagelayout', $arrVal);
            } else {
                plg_AmazonPaymentsV2_SC_Utils::printLog("installSQL already exist record device_type_id=" . DEVICE_TYPE_SMARTPHONE . " url=" . $pageData['file_name'] . ".php in dtb_pagelayout.");
            }
        }
    }
    function lfInsertCsv(&$objQuery)
    {
        $arrCsv = self::lfGetCsv();
        foreach ($arrCsv as $csv) {
            $max = array_pop($objQuery->getRow('max(no)', 'dtb_csv'));
            $next_seq = $objQuery->nextVal('dtb_csv_no');
            $no = ($max + 1 <= $next_seq) ? $next_seq : $max + 1;
            if (!$objQuery->exists('dtb_csv', 'col = ? AND disp_name = ?', array($csv['col'], $csv['disp_name']))) {
                $arrVal = array('no' => $no, 'csv_id' => 3, 'col' => $csv['col'], 'disp_name' => $csv['disp_name'], 'rank' => NULL, 'rw_flg' => 2, 'status' => 1, 'create_date' => 'CURRENT_TIMESTAMP', 'update_date' => 'CURRENT_TIMESTAMP',);
                $objQuery->insert('dtb_csv', $arrVal);
            } else {
                plg_AmazonPaymentsV2_SC_Utils::printLog("installSQL already exist record disp_name=" . $csv['disp_name'] . " in dtb_csv.");
            }
        }
    }
    function lfInsertConstants(&$objQuery)
    {
        $arrConstants = self::lfGetConstants();
        foreach ($arrConstants as $constants) {
            if (!$objQuery->exists('mtb_constants', 'id = ?', array($constants['id']))) {
                $rank = $objQuery->max('rank', 'mtb_constants') + 1;
                $arrVal = array('id' => $constants['id'], 'name' => $constants['name'], 'rank' => $rank, 'remarks' => $constants['remarks'],);
                $objQuery->insert('mtb_constants', $arrVal);
            } else {
                plg_AmazonPaymentsV2_SC_Utils::printLog("installSQL already exist record id=" . $constants['id'] . "in mtb_constants.");
            }
        }
    }
    function lfInsertPayment(&$objQuery)
    {
        $max = array_pop($objQuery->getRow('max(payment_id)', 'dtb_payment'));
        $next_seq = $objQuery->nextVal('dtb_payment_payment_id');
        $no = ($max + 1 <= $next_seq) ? $next_seq : $max + 1;
        if (!$objQuery->exists('dtb_payment', 'memo03 = ?', array('amazonpaymentsV2'))) {
            $arrVal = array('payment_id' => $no, 'payment_method' => 'Amazon Pay', 'charge' => 0, 'rank' => NULL, 'fix' => 2, 'status' => 1, 'del_flg' => 0, 'creator_id' => $_SESSION['member_id'], 'create_date' => 'CURRENT_TIMESTAMP', 'update_date' => 'CURRENT_TIMESTAMP', 'module_path' => '', 'memo03' => 'amazonpaymentsV2', 'rule_min' => 9999999, 'rule_max' => 9999999, 'upper_rule' => 9999999, 'upper_rule_max' => 9999999,);
            $objQuery->insert('dtb_payment', $arrVal);
            $payment_id = $objQuery->get('payment_id', 'dtb_payment', 'memo03 = ?', array('amazonpaymentsV2'));
            $objQuery->setGroupBy('deliv_id');
            $arrDelivList = $objQuery->select('deliv_id, max(rank)', 'dtb_payment_options');
            foreach ($arrDelivList as $deliv) {
                $deliv_id = $deliv['deliv_id'];
                $rank = $deliv['max(rank)'] + 1;
                $arrVal = array('deliv_id' => $deliv_id, 'payment_id' => $payment_id, 'rank' => $rank,);
                $objQuery->insert('dtb_payment_options', $arrVal);
            }
        } else {
            plg_AmazonPaymentsV2_SC_Utils::printLog("installSQL already exist record payment_method='AmazonPay' in dtb_payment.");
        }
    }
    function lfDeletePayment(&$objQuery)
    {
        $payment_id = $objQuery->get('payment_id', 'dtb_payment', 'memo03 = ?', array('amazonpaymentsV2'));
        $objQuery->delete('dtb_payment_options', 'payment_id = ?', array($payment_id));
        $objQuery->delete('dtb_payment', 'memo03 = ?', array('amazonpaymentsV2'));
    }
    function lfDeletePagelayout(&$objQuery)
    {
        $arrPageData = self::lfGetPagelayout();
        foreach ($arrPageData as $pageData) {
            $objQuery->delete('dtb_pagelayout', 'url = ?', array($pageData['file_name'] . '.php'));
        }
    }
    function lfDeleteCsv(&$objQuery)
    {
        $arrCsv = self::lfGetCsv();
        foreach ($arrCsv as $csv) {
            $objQuery->delete('dtb_csv', 'col = ? AND disp_name = ?', array($csv['col'], $csv['disp_name']));
        }
    }
    function lfDeleteConstants(&$objQuery)
    {
        $arrConstants = self::lfGetConstants();
        foreach ($arrConstants as $constants) {
            $objQuery->delete('mtb_constants', 'id = ?', array($constants['id']));
        }
    }
    function lfGetPagelayout()
    {
        $arrPageData = array(array('page_name' => '商品購入/Amazon Pay V2(入力ページ)', 'file_name' => 'shopping/plg_AmazonPaymentsV2_payment'), array('page_name' => '商品購入/Amazon Pay V2(確認ページ)', 'file_name' => 'shopping/plg_AmazonPaymentsV2_confirm'),);
        return $arrPageData;
    }
    function lfGetCsv()
    {
        $arrCsv = array(array('col' => 'memo06 as plg_amazonpaymentsv2_amazon_reference_id', 'disp_name' => 'Amazon参照ID'), array('col' => 'memo07 as plg_amazonpaymentsv2_amazon_status_name', 'disp_name' => 'Amazon状況'),);
        return $arrCsv;
    }
    function lfGetConstants()
    {
        $arrConstants = array(array('id' => 'AMAZONPAYV2_SC_PARAMETER', 'name' => '"orderReferenceId"', 'remarks' => 'SellerCentral受注詳細へのパラメータ(Amazon Pay V2)'),);
        return $arrConstants;
    }
    function cartCheckAble(LC_Page_Ex $objPage)
    {
        if (empty($objPage->cartItems)) {
            return;
        }
        $cartItems = $objPage->cartItems;
        $AmazonDelivList = plg_AmazonPaymentsV2_SC_Utils::getAmazonDelivList($cartItems[0]["productsClass"]["product_type_id"]);
        return $AmazonDelivList;
    }
}
